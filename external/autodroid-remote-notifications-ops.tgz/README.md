# Remote Notifications deployment control

This directory deploys versioned server artifacts from
`MyPowerTools-remote-notifications` to the production host.

The server source remains in its product repository. Every deployment records
the product Git SHA and artifact SHA-256 in `versions.json`.

Example:

```bash
python ops/remote-notifications/deploy.py \
  --target proxy.lixinrui000.cn \
  --confirm-target proxy.lixinrui000.cn \
  --artifact remote-notifications-server.tar.gz \
  --version 0.3.0-session-metadata \
  --git-sha <full-sha>
```

Use `--dry-run` to print the validated deployment without changing the target.

